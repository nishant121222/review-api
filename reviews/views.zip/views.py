from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions
from django.shortcuts import get_object_or_404
from accounts.models import AdminUser  # your custom user model
from businesses.models import Business
from .models import Review
from .services import handle_high_rating_review, handle_approved_review
from drf_yasg.utils import swagger_auto_schema


class SubmitReviewView(APIView):
    """
    Public endpoint – customers submit reviews (no JWT required).
    """
    permission_classes = [permissions.AllowAny]

    @swagger_auto_schema(security=[])
    def post(self, request):
        user_id = request.data.get('user_id')
        business_id = request.data.get('business_id')
        rating = request.data.get('rating')
        comment = request.data.get('comment', '')

        # Validate required fields
        if not (user_id and business_id and rating):
            return Response(
                {'error': 'user_id, business_id, rating are required'},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Validate rating type
        try:
            rating = int(rating)
        except ValueError:
            return Response({'error': 'rating must be an integer'}, status=status.HTTP_400_BAD_REQUEST)

        # Get user and business
        user = get_object_or_404(AdminUser, id=user_id)
        business = get_object_or_404(Business, id=business_id)

        # Determine review status
        review_status = 'published' if rating >= 4 else 'pending'

        try:
            # Create the review
            review = Review.objects.create(
                user=user,
                business=business,
                rating=rating,
                comment=comment,
                status=review_status
            )

            # Optional: handle high rating reviews
            if rating >= 4:
                try:
                    handle_high_rating_review(review)
                except Exception as e:
                    print(f"High rating handler error: {e}")

            return Response({'id': review.id, 'status': review.status}, status=status.HTTP_201_CREATED)

        except Exception as e:
            return Response({'error': f'Unexpected error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class PendingReviewsView(APIView):
    """
    Public endpoint – view all pending reviews (no JWT required).
    """
    permission_classes = [permissions.AllowAny]

    @swagger_auto_schema(security=[])
    def get(self, request):
        qs = Review.objects.filter(status='pending').order_by('-created_at')
        data = [{
            'id': r.id,
            'user_phone': getattr(r.user, 'phone', 'N/A'),
            'rating': r.rating,
            'comment': r.comment,
            'created_at': r.created_at.isoformat(),
        } for r in qs]
        return Response({'reviews': data})


class ApproveReviewView(APIView):
    """
    Public endpoint – approve a pending review (no JWT required).
    """
    permission_classes = [permissions.AllowAny]

    @swagger_auto_schema(security=[])
    def post(self, request, review_id):
        review = get_object_or_404(Review, id=review_id, status='pending')

        # Safely handle moderated_by
        try:
            review.moderated_by = request.user.id if hasattr(request, 'user') else None
        except Exception:
            review.moderated_by = None

        review.status = 'approved'
        review.save()

        # Safely run the approved review handler
        try:
            handle_approved_review(review)
        except Exception as e:
            print(f"Approved review handler failed: {e}")

        return Response({'status': 'approved'})


class RejectReviewView(APIView):
    """
    Public endpoint – reject a pending review (no JWT required).
    """
    permission_classes = [permissions.AllowAny]

    @swagger_auto_schema(security=[])
    def post(self, request, review_id):
        review = get_object_or_404(Review, id=review_id, status='pending')

        # Safely handle moderated_by
        try:
            review.moderated_by = request.user.id if hasattr(request, 'user') else None
        except Exception:
            review.moderated_by = None

        review.status = 'rejected'
        review.save()

        return Response({'status': 'rejected'})
